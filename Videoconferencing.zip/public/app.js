const socket = io();

// Get the room ID (e.g., via URL or user input)
const roomId = 'your-room-id'; // You can dynamically generate this or ask users for input
const userId = Math.random().toString(36).substr(2, 9); // Random user ID for example

// Join the room
socket.emit('join-room', roomId, userId);

// Handle incoming signaling messages
socket.on('user-joined', (userId) => {
  createPeerConnection(userId);
});

// Handle incoming offer
socket.on('offer', async ({ offer, userId }) => {
  await peerConnections[userId].setRemoteDescription(new RTCSessionDescription(offer));
  const answer = await peerConnections[userId].createAnswer();
  await peerConnections[userId].setLocalDescription(answer);
  socket.emit('answer', { roomId, answer, userId });
});

// Handle incoming answer
socket.on('answer', async ({ answer, userId }) => {
  await peerConnections[userId].setRemoteDescription(new RTCSessionDescription(answer));
});

// Handle ICE candidates
socket.on('ice-candidate', async ({ candidate, userId }) => {
  await peerConnections[userId].addIceCandidate(new RTCIceCandidate(candidate));
});

// WebRTC: Get user media (camera and microphone)
navigator.mediaDevices.getUserMedia({ video: true, audio: true })
  .then((stream) => {
    const localVideo = document.getElementById('localVideo');
    localVideo.srcObject = stream;
    localStream = stream;
  })
  .catch((err) => console.error('Error accessing media devices:', err));

let peerConnections = {};
let localStream = null;

// Create a peer connection for a new user
function createPeerConnection(userId) {
  const peerConnection = new RTCPeerConnection({
    iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
  });

  // Add local media stream tracks to the peer connection
  localStream.getTracks().forEach((track) => peerConnection.addTrack(track, localStream));

  // Handle remote media stream
  peerConnection.ontrack = (event) => {
    const remoteStream = event.streams[0];
    const remoteVideo = document.createElement('video');
    remoteVideo.srcObject = remoteStream;
    remoteVideo.autoplay = true;
    remoteVideo.playsInline = true;
    document.getElementById('videoContainer').appendChild(remoteVideo);
  };

  // Handle ICE candidates
  peerConnection.onicecandidate = (event) => {
    if (event.candidate) {
      socket.emit('ice-candidate', { roomId, candidate: event.candidate, userId });
    }
  };

  // Create and send offer to the other user
  peerConnection.createOffer().then((offer) => {
    peerConnection.setLocalDescription(offer);
    socket.emit('offer', { roomId, offer, userId });
  });

  peerConnections[userId] = peerConnection;
}
